import React from 'react';
import "./style.css"
import OneLine from "./../oneLine/oneLine"

class Tree extends React.Component{
    constructor(props){
        super(props);
    }

    makeElements(arr){
        let elements = [];
        let children = [];
        let subchildren = [];
        arr.forEach((element , i) => {
            element.children.forEach((child,j)=>{
                // children = []
                subchildren = child.subchildren.map((subchildren,k)=>{
                    return(
                        <OneLine typeOfElement = "subchild" name = {subchildren.name} index = {k}></OneLine>
                    )
                })
                children = [
                    ...children,
                    <OneLine typeOfElement = "child" name = {child.name} index = {j}></OneLine>,
                    ...subchildren
                ]                
            })
            elements = [
                ...elements,
                <OneLine typeOfElement = "element" name = {element.name} index = {i}></OneLine>,
                ...children
            ]
            children = []
        })
        return elements;
    }

    render(){
        return(
            <div className = "tree">
                <OneLine name = "TOP LEVEL"></OneLine>
                {this.makeElements(this.props.content)}
            </div>
        )
    }
}

export default Tree;